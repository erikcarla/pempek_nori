package com.lokalpos.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val color: String = "#4CAF50",
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
